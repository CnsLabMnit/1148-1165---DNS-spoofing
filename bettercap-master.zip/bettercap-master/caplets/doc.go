// Package caplets contains functions to enumerate, load and execute caplets.
package caplets
